<?php $__env->startSection('top'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header"><strong><?php echo e($user->name); ?></strong></div>
                    <div class="card-body">
                        <img style="max-height: 400px" class="img-fluid card-img-top" id="newProfilePhoto" src="/photo/<?php echo e($user->info->avatar); ?>" alt="Photo">
                        <a href="javascript:void(0)"  role="button" class="btn-outline-success btn mt-2 float-right" onclick="profilePicUpload()"><i class='fa fa-camera'></i> <span>Change Photo</span></a>
                        <form id="profilePhoto">
                            <input type="hidden" name="photo" value="<?php echo e($user->info->avatar); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="file" accept="image/*" name="avatar" id="customFile" style="display: none;">
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <?php echo e($user); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        profilePicUpload=()=>{
            $('#customFile').click();
        }
        $(function () {
            $("#customFile").on('change',function (e)
            {
                e.preventDefault();
                let form = $('#profilePhoto')[0];
                let data = new FormData(form);
                $.ajax({
                    type: "POST",
                    url: '<?php echo e(route('profile')); ?>',
                    mimeType: "multipart/form-data",
                    data: data,
                    processData: false,
                    contentType: false,
                    cache: false,
                    async: false,
                    success: function (data)
                    {
                        $('#profilePhoto')[0].reset();
                        $('#newProfilePhoto').attr('src','<?php echo e(url('/photo/')); ?>/'+data);
                    }
                });
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alauddin\Desktop\Task\resources\views/profile.blade.php ENDPATH**/ ?>