<?php $__env->startSection('top'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><strong>Data shows around 5 KM</strong></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <?php if(count($users)): ?>
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>Distance</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><img style="height: 40px;width: 40px;border-radius: 50%" class="img-thumbnail mr-2" src="" alt="Photo" srcset="/photo/<?php echo e($user->avatar); ?>"><?php echo e($user->user->name); ?><sub class="ml-1">(Age: <?php echo e($user->age); ?> Years)</sub></td>
                                        <td><?php echo e($user->gender==1 ? 'Male' : 'Female'); ?></td>
                                        <td><?php echo e(round($user->distance,2)); ?> KM</td>
                                        <td>
                                            <a href="javascript:void(0)" onclick="like('<?php echo e($user->user_id); ?>')"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></a>  
                                            <a href="javascript:void(0)"><i class="fa fa-thumbs-o-down ml-2" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        like=(otherId)=>{
            $.ajax({
                url: '<?php echo e(route('like')); ?>',
                type: 'POST',
                data:{likedUser:otherId,_token:'<?php echo e(csrf_token()); ?>'},
                success: function (data) {
                    if (data.success)
                    {
                        alert(data.success);
                    }
                    else{
                        console.log(data)
                    }
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alauddin\Desktop\Task\resources\views/home.blade.php ENDPATH**/ ?>